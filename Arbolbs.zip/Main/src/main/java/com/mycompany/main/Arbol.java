/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;
public class Arbol {
    Nodo raiz;

    void insertar(int valor) {
        raiz = insertarRec(raiz, valor);
    }

    Nodo insertarRec(Nodo raiz, int valor) {
        if (raiz == null) {
            raiz = new Nodo(valor);
            return raiz;
        }

        if (valor < raiz.valor) {
            raiz.izq = insertarRec(raiz.izq, valor);
        } else if (valor > raiz.valor) {
            raiz.der = insertarRec(raiz.der, valor);
        }

        return raiz;
    }

    boolean buscar(int valor) {
        return buscarRe(raiz, valor);
    }

    boolean buscarRe(Nodo raiz, int valor) {
        if (raiz == null) {
            return false;
        }
        if (valor == raiz.valor) {
            return true;
        }

        if (valor > raiz.valor) {
            return buscarRe(raiz.der, valor);
        }

        return buscarRe(raiz.izq, valor);
    }

    void eliminar(int valor) {
        raiz = eliminarRe(raiz, valor);
    }

    Nodo eliminarRe(Nodo raiz, int valor) {
        if (raiz == null) {
            return null;
        }

        if (valor < raiz.valor) {
            raiz.izq = eliminarRe(raiz.izq, valor);
        } else if (valor > raiz.valor) {
            raiz.der = eliminarRe(raiz.der, valor);
        } else {
            if (raiz.izq == null) {
                return raiz.der;
            } else if (raiz.der == null) {
                return raiz.izq;
            }

            Nodo temp = encontrarMin(raiz.der);
            raiz.valor = temp.valor;
            raiz.der= eliminarRe(raiz.der, temp.valor);
        }

        return raiz;
    }

    Nodo encontrarMin(Nodo raiz) {
        Nodo actual = raiz;
        while (actual.izq != null) {
            actual = actual.izq;
        }
        return actual;
    }

    void actualizar(int valorAntiguo, int valorNuevo) {
        eliminar(valorAntiguo);
        insertar(valorNuevo);
    }

    public static int getcol(int h) {
        if (h == 1) {
            return 1;
        }
        return getcol(h - 1) + getcol(h - 1) + 1;
    }

    public static void printTree(int[][] M, Nodo root, int col, int row, int height) {
        if (root == null) {
            return;
        }
        M[row][col] = root.valor;
        printTree(M, root.izq, col - (int) Math.pow(2, height - 2), row + 1, height - 1);
        printTree(M, root.der, col + (int) Math.pow(2, height - 2), row + 1, height - 1);
    }

    public int alturaArbol(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }
        int alturaIzquierda = alturaArbol(nodo.izq);
        int alturaDerecha = alturaArbol(nodo.der);
        return Math.max(alturaIzquierda, alturaDerecha) + 1;
    }

    public void TreePrinter() {
        int h = alturaArbol(this.raiz);
        int col = getcol(h);
        int[][] M = new int[h][col];
        printTree(M, this.raiz, col / 2, 0, h);
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < col; j++) {
                if (M[i][j] == 0) {
                    System.out.print("  ");
                } else {
                    System.out.print(M[i][j] + " ");
                }
            }
            System.out.println();
        }
    }
}
