/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Arbol arbol = new Arbol();

        System.out.println("Ingrese la cantidad de valores que desea agregar al arbol:");
        int cantidad = scanner.nextInt();

        for (int i = 0; i < cantidad; i++) {
            System.out.println("Ingrese un valor para agregar al arbol:");
            int valor = scanner.nextInt();
            arbol.insertar(valor);
        }
        System.out.println(" ");
        System.out.println(" ");
        System.out.println("Arbol: ");
        arbol.TreePrinter();

        int opcion;
        do {
            System.out.println("\nSeleccione una opcion: ");
            System.out.println("1. Buscar un valor");
            System.out.println("2. Actualizar un valor");
            System.out.println("3. Eliminar un valor");
            System.out.println("4. Imprimir el arbol");
            System.out.println("5. Salir");
            opcion = scanner.nextInt();

            if (opcion == 1) {
                System.out.println("Ingrese el valor que desea buscar: ");
                int valorBuscar = scanner.nextInt();
                boolean encontrado = arbol.buscar(valorBuscar);
                if (encontrado) {
                    System.out.println("El valor " + valorBuscar + " esta en el arbol.");
                } else {
                    System.out.println("El valor " + valorBuscar + " no esta en el arbol.");
                }
            } else if (opcion == 2) {
                System.out.println("Ingrese el valor que desea actualizar: ");
                int valorAntiguo = scanner.nextInt();
                System.out.println("Ingrese el nuevo valor: ");
                int valorNuevo = scanner.nextInt();
                if (arbol.buscar(valorAntiguo)) {
                    arbol.actualizar(valorAntiguo, valorNuevo);
                    System.out.println("Valor actualizado.");
                } else {
                    System.out.println("El valor " + valorAntiguo + " no esta en el arbol.");
                }
            } else if (opcion == 3) {
                System.out.println("Ingrese el valor que desea eliminar: ");
                int valorEliminar = scanner.nextInt();
                if (arbol.buscar(valorEliminar)) {
                    arbol.eliminar(valorEliminar);
                    System.out.println("Valor eliminado.");
                } else {
                    System.out.println("El valor " + valorEliminar + " no esta en el arbol.");
                }
            } else if (opcion == 4) {
                System.out.println("Aqui esta la representacion del arbol: ");
                arbol.TreePrinter();
            } else if (opcion == 5) {
                System.out.println("Saliendo...");
            } else {
                System.out.println("Opcion no valida.");
            }

        } while (opcion != 5);

        scanner.close();
    }
}
