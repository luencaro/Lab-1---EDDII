/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;
public class Nodo {
    int valor;
    Nodo izq, der;

    Nodo(int item) {
        valor = item;
        izq = der = null;
    }
}
